// ===== নিজের মতো ওজন + নতুন গিফট বক্স (Royal Family Box-এর ধরনে) =====
// দাম: ১ কেজির দাম ÷ ১০০০ × গ্রাম। বক্সে নিলে ছাড় (ড্যাশবোর্ড থেকে বদলানো যায়)।
// ডেমো আর আসল সাইট দুটোতেই চলে; আসল সাইটে নিয়মগুলো সার্ভার থেকে আসে (window.SITE_RULES)।
(function () {
  'use strict';
  const RULES = () => Object.assign({ weight: { min: 100, step: 100, max: 10000 }, box: { pct: 5, tiers: [] } }, window.SITE_RULES || {});
  const gramsOf = (w) => { const m = String(w || '').match(/([\d.]+)\s*(kg|g)\b/i); return m ? Math.round(+m[1] * (m[2].toLowerCase() === 'kg' ? 1000 : 1)) : 0; };
  // The 1 kg size of a product (own weight is possible only then).
  const kgOf = (p) => { if (!p) return null; if (p.kg) return p.kg; const i = p.v.findIndex((v) => gramsOf(v.w) === 1000); return i < 0 ? null : { id: p.v[i].id, p: p.v[i].p, i }; };
  const gPrice = (p, g) => { const k = kgOf(p); return k ? Math.round(k.p * g / 1000) : 0; };
  const gLabel = (g) => (g >= 1000 && g % 1000 === 0 ? bn(g / 1000) + ' কেজি' : bn(g) + ' গ্রাম');
  const boxPct = (count) => { const b = RULES().box; let pct = +b.pct || 0; (b.tiers || []).forEach((t) => { if (count >= (+t.min || 0) && (+t.pct || 0) > pct) pct = +t.pct; }); return pct; };
  window.WB = { kgOf, gPrice, gramsOf, boxPct };

  const css = document.createElement('style');
  css.textContent = `
  .ownw{display:flex;flex-wrap:wrap;align-items:center;gap:10px;border:1px dashed var(--gold);border-radius:14px;padding:12px;background:var(--soft)}
  .ownw b{flex-basis:100%;font-size:14px}
  .stp{display:inline-flex;align-items:center;border:1px solid var(--line);border-radius:12px;background:var(--surface);overflow:hidden}
  .stp button{width:40px;height:40px;border:0;background:none;font-size:20px;color:var(--brand);cursor:pointer;font-family:inherit}
  .stp span{min-width:86px;text-align:center;font-weight:700;font-size:15px}
  .ownw .owp{font-weight:700;color:var(--brand);font-size:16px}
  .ownw .btn{flex:1;min-width:140px}
  .bx{display:flex;flex-direction:column;gap:14px}
  .bx-stage{position:relative;border-radius:18px;background:linear-gradient(160deg,#0B4A2F,#07311F);padding:18px 16px 16px;color:#F4EFE3;overflow:hidden}
  .bx-lid{height:16px;margin:0 6% -4px;border-radius:10px 10px 4px 4px;background:linear-gradient(90deg,#B8902A,#E7CC74,#B8902A);box-shadow:0 4px 10px rgba(0,0,0,.25)}
  .bx-box{position:relative;min-height:150px;border:2px solid #D4AF37;border-radius:6px 6px 14px 14px;background:repeating-linear-gradient(135deg,rgba(255,255,255,.03) 0 10px,transparent 10px 20px),#0F5A3A;padding:14px 12px 12px;display:flex;flex-wrap:wrap;align-content:flex-start;gap:8px}
  .bx-box:before{content:"";position:absolute;left:50%;top:-2px;bottom:-2px;width:16px;transform:translateX(-50%);background:linear-gradient(90deg,#B8902A,#E7CC74,#B8902A);opacity:.35;pointer-events:none}
  .bx-empty{margin:auto;text-align:center;color:#E7CC74;font-size:14px;line-height:1.6;opacity:.9}
  .bx-it{position:relative;z-index:1;display:flex;align-items:center;gap:6px;background:#FFFDF7;color:#1F2A22;border-radius:999px;padding:4px 10px 4px 4px;font-size:13px;box-shadow:0 2px 6px rgba(0,0,0,.25)}
  .bx-it img,.bx-it .dot{width:30px;height:30px;border-radius:50%;object-fit:cover;background:#E7CC74;flex:none}
  .bx-it button{border:0;background:none;color:#B3261E;font-size:16px;cursor:pointer;padding:0 2px}
  .bx-it.pop{animation:bxpop .45s cubic-bezier(.3,1.6,.5,1)}
  @keyframes bxpop{0%{transform:scale(.2);opacity:0}100%{transform:scale(1);opacity:1}}
  .bx-cap{display:flex;justify-content:space-between;align-items:baseline;margin-top:10px;font-size:14px}
  .bx-cap b{font-size:18px;color:#F2D98C}
  .bx-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}
  .bx-p{border:1px solid var(--line);border-radius:14px;background:var(--surface);padding:8px;display:flex;flex-direction:column;gap:6px}
  .bx-p .pimgx,.bx-p .ph{width:100%;height:auto;aspect-ratio:1;border-radius:10px;object-fit:cover}
  .bx-p b{font-size:13.5px;line-height:1.35}
  .bx-p .stp button{width:32px;height:34px;font-size:18px}.bx-p .stp span{min-width:64px;font-size:13px}
  .bx-p .pr{font-weight:700;color:var(--brand)}
  .bx-p .add{min-height:38px}
  .bx-cnt{display:flex;align-items:center;gap:12px;flex-wrap:wrap}
  .bx-cnt input{width:90px;text-align:center;border:1px solid var(--line);border-radius:10px;padding:10px;font:inherit;font-size:16px}
  .bx-sum .old{text-decoration:line-through;color:var(--muted)}
  @media (min-width:1024px){.bx{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,1fr);align-items:start}.bx-stage{position:sticky;top:158px}.bx-head{grid-column:1/-1}}
  `;
  document.head.appendChild(css);

  // ---- কার্টে "id|g300" = ৩০০ গ্রাম; বক্স "gb_…" = সাজানো বক্স × সংখ্যা ----
  const _item = item;
  item = function (k) {
    const m = /^(.+)\|g(\d+)$/.exec(k);
    if (m) { const p = byId(m[1]); const g = +m[2]; if (!p || !kgOf(p)) return null; return { name: p.name, w: gLabel(g), p: gPrice(p, g), img: p.img, pid: p.id, grams: g }; }
    if (k.startsWith('gb_') && GB[k] && GB[k].box) {
      const g = GB[k]; const t = boxTotals(g.box, g.count);
      return { name: 'গিফট বক্স' + (g.to ? ' · ' + g.to + '-এর জন্য' : ''), w: `${bn(g.box.length)}টি জিনিস × ${bn(g.count)}টা বক্স`, p: t.net, img: 'royal', gb: { ...g, items: g.box.map((x) => `${x.name.split(' (')[0]} ${x.w}`) } };
    }
    return _item(k);
  };

  // ---- পণ্যের পাতায় "নিজের মতো ওজন" ----
  const ow = {};
  function ownBlock(p) {
    const r = RULES().weight; const g = ow[p.id] || 500;
    return `<div class="ownw" id="ownw"><b>নিজের মতো ওজন <small style="font-weight:400;color:var(--muted)">(১ কেজির দরে, ${bn(r.step)} গ্রাম করে)</small></b>
      <div class="stp"><button type="button" data-ow="-" aria-label="কমান">−</button><span>${gLabel(g)}</span><button type="button" data-ow="+" aria-label="বাড়ান">+</button></div>
      <span class="owp">${tk(gPrice(p, g))}</span><button type="button" class="btn ghost" data-owadd="${p.id}">এই ওজনে কার্টে যোগ করুন</button></div>`;
  }
  const _render = render;
  render = function () {
    const out = _render.apply(this, arguments);
    const h = location.hash || '';
    if (h.startsWith('#p-')) {
      const p = byId(h.slice(3)); const at = document.querySelector('#pdp .vchips, #pdp .wtag');
      if (p && kgOf(p) && at && !document.getElementById('ownw')) at.insertAdjacentHTML('afterend', ownBlock(p));
    }
    return out;
  };

  // ---- নতুন গিফট বক্স ----
  let BOX = []; let COUNT = 1; const pickW = {};
  const boxable = () => P.filter((p) => p.v.length && p.cat !== 'gift' && !p.hide);
  function lineOf(p, sel) { // sel = {g} or {i}
    if (sel.g) return { k: p.id + '|g' + sel.g, name: p.name, w: gLabel(sel.g), p: gPrice(p, sel.g), img: p.img, pid: p.id };
    const v = p.v[sel.i]; return { k: p.id + '|' + sel.i, name: p.name, w: v.w, p: v.p, img: p.img, pid: p.id };
  }
  function boxTotals(box, count) {
    const one = box.reduce((a, x) => a + x.p, 0); const gross = one * count; const pct = boxPct(count);
    const disc = Math.round(gross * pct / 100); return { one, gross, pct, disc, net: gross - disc };
  }
  const thumb = (img) => (img ? `<img src="img/${img}.jpg" alt="" loading="lazy">` : '<span class="dot"></span>');
  function stage() {
    const t = boxTotals(BOX, COUNT);
    return `<div class="bx-stage" id="bxStage"><div class="bx-lid"></div><div class="bx-box" id="bxBox">${BOX.length ? BOX.map((x, i) =>
      `<span class="bx-it${x.pop ? ' pop' : ''}">${thumb(x.img)}${esc(x.name.split(' (')[0])} · ${esc(x.w)}<button type="button" data-bxdel="${i}" aria-label="বাদ দিন">×</button></span>`).join('')
      : '<div class="bx-empty">নিচ থেকে জিনিস বেছে <b>বক্সে দিন</b><br>চাপুন — এখানে এসে বসবে</div>'}</div>
      <div class="bx-cap"><span>এক বক্সের দাম</span><b>${tk(Math.round(t.one * (1 - t.pct / 100)))}</b></div></div>`;
  }
  ROUTES.giftbox = function () {
    BOX.forEach((x) => { delete x.pop; });
    const t = boxTotals(BOX, COUNT); const r = RULES().weight;
    return `<section class="sec pad"><button class="back" data-back>← ফিরে যান</button>
    <div class="bx"><div class="bx-head"><span class="eyebrow">BUILD YOUR OWN GIFT BOX</span><h2>নিজের মতো গিফট বক্স সাজান</h2>
     <p style="margin:0;color:var(--muted);font-size:14px;line-height:1.7">Royal Family Box-এর মতো সাজানো বক্সে প্রতিজনের জন্য কী কী যাবে বেছে নিন। খোলা জিনিস ১ কেজির দরে যত গ্রাম চান। বক্সে নিলে <b>${bn(boxPct(COUNT))}% কম দাম</b>।</p></div>
     ${stage()}
     <div style="display:flex;flex-direction:column;gap:14px">
      <div class="bx-list">${boxable().map((p) => {
        const k = kgOf(p); const g = pickW[p.id] || 500;
        const ctl = k ? `<div class="stp"><button type="button" data-bxw="${p.id}" data-d="-">−</button><span>${gLabel(g)}</span><button type="button" data-bxw="${p.id}" data-d="+">+</button></div><span class="pr">${tk(gPrice(p, g))}</span>`
          : `<div class="vchips">${p.v.map((v, i) => `<button class="vchip" type="button" data-bxv="${p.id}" data-vi="${i}" aria-pressed="${(pickW[p.id + 'v'] || 0) === i}">${v.w}</button>`).join('')}</div><span class="pr">${tk(p.v[pickW[p.id + 'v'] || 0].p)}</span>`;
        return `<div class="bx-p" data-bxp="${p.id}">${pic(p)}<b>${p.name}</b>${ctl}<button type="button" class="add" data-bxadd="${p.id}">বক্সে দিন</button></div>`;
      }).join('')}</div>
      <div class="bx-cnt"><b style="font-size:15px">কতজনের জন্য (কতটা বক্স)?</b><div class="stp"><button type="button" data-bxc="-">−</button><span id="bxCnt">${bn(COUNT)}টা</span><button type="button" data-bxc="+">+</button></div><input id="bxCntIn" type="number" inputmode="numeric" min="1" value="${COUNT}" aria-label="বক্সের সংখ্যা"></div>
      <label class="f">কাকে দিচ্ছেন? (ঐচ্ছিক)<input id="gbTo" placeholder="যেমন: বিয়ের অতিথি / অফিসের সবাই"></label>
      <label class="f">কার্ডের বার্তা (ঐচ্ছিক)<textarea id="gbMsg" rows="2" placeholder="যেমন: আমাদের আনন্দে শরিক হওয়ার জন্য ধন্যবাদ"></textarea></label>
      <div class="sum bx-sum" id="bxSum">${sumHtml(t)}</div>
      <p class="err" id="gbErr" hidden></p>
      <button class="btn" type="button" data-bxcart>বক্স কার্টে যোগ করুন · <span id="bxBtnT">${tk(t.net)}</span></button>
      <small style="color:var(--muted)">সবচেয়ে কম ${bn(r.min)} গ্রাম, ${bn(r.step)} গ্রাম করে বাড়ানো যায়।</small>
     </div></div></section>`;
  };
  function sumHtml(t) {
    return `<div><span>এক বক্সে</span><span>${tk(t.one)}</span></div><div><span>বক্সের সংখ্যা</span><span>× ${bn(COUNT)}</span></div>
      ${t.disc ? `<div><span>সাধারণ দাম</span><span class="old">${tk(t.gross)}</span></div><div class="savel"><span>বক্সে ছাড় (${bn(t.pct)}%)</span><span>−${tk(t.disc)}</span></div>` : ''}
      <div class="tot"><span>মোট</span><span>${tk(t.net)}</span></div>`;
  }
  // Only redraw the parts that change (so typed text and scroll stay put).
  function redraw() {
    const st = document.getElementById('bxStage'); if (st) st.outerHTML = stage();
    const t = boxTotals(BOX, COUNT);
    const s = document.getElementById('bxSum'); if (s) s.innerHTML = sumHtml(t);
    const b = document.getElementById('bxBtnT'); if (b) b.textContent = tk(t.net);
    const c = document.getElementById('bxCnt'); if (c) c.textContent = bn(COUNT) + 'টা';
    const ci = document.getElementById('bxCntIn'); if (ci && +ci.value !== COUNT) ci.value = COUNT;
  }

  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-ow],[data-owadd],[data-bxw],[data-bxv],[data-bxadd],[data-bxdel],[data-bxc],[data-bxcart]');
    if (!t) return;
    e.preventDefault(); e.stopPropagation();
    const r = RULES().weight; const step = (g, d) => Math.min(r.max || 10000, Math.max(r.min, g + (d === '+' ? r.step : -r.step)));
    if (t.dataset.ow) {
      const p = byId(location.hash.slice(3)); ow[p.id] = step(ow[p.id] || 500, t.dataset.ow);
      document.getElementById('ownw').outerHTML = ownBlock(p);
    } else if (t.dataset.owadd) {
      const p = byId(t.dataset.owadd); const g = ow[p.id] || 500;
      const src = document.querySelector('#pdp .pimgx,#pdp .ph');
      addKey(p.id + '|g' + g, 1, p.id);
      const fc = document.getElementById('fcart'); if (typeof fly === 'function') fly(src, fc && !fc.hidden ? fc : document.querySelector('#bnav [data-nav="cart"] .ic'));
      if (typeof updFcart === 'function') updFcart();
    } else if (t.dataset.bxw) {
      const id = t.dataset.bxw; pickW[id] = step(pickW[id] || 500, t.dataset.d);
      const card = t.closest('.bx-p'); const p = byId(id);
      card.querySelector('.stp span').textContent = gLabel(pickW[id]); card.querySelector('.pr').textContent = tk(gPrice(p, pickW[id]));
    } else if (t.dataset.bxv !== undefined && t.dataset.bxv) {
      const id = t.dataset.bxv; pickW[id + 'v'] = +t.dataset.vi; const card = t.closest('.bx-p');
      card.querySelectorAll('.vchip').forEach((b) => b.setAttribute('aria-pressed', b === t));
      card.querySelector('.pr').textContent = tk(byId(id).v[+t.dataset.vi].p);
    } else if (t.dataset.bxadd) {
      const p = byId(t.dataset.bxadd); const line = kgOf(p) ? lineOf(p, { g: pickW[p.id] || 500 }) : lineOf(p, { i: pickW[p.id + 'v'] || 0 });
      const src = t.closest('.bx-p').querySelector('.pimgx,.ph'); const dst = document.getElementById('bxBox');
      if (typeof fly === 'function' && src && dst) fly(src, dst);
      setTimeout(() => { BOX.push({ ...line, pop: true }); redraw(); }, matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 820);
    } else if (t.dataset.bxdel !== undefined) {
      BOX.splice(+t.dataset.bxdel, 1); redraw();
    } else if (t.dataset.bxc) {
      COUNT = Math.max(1, Math.min(1000, COUNT + (t.dataset.bxc === '+' ? 1 : -1))); redraw();
    } else if (t.hasAttribute('data-bxcart')) {
      const er = document.getElementById('gbErr');
      if (!BOX.length) { er.textContent = 'বক্সে অন্তত একটা জিনিস দিন।'; er.hidden = false; return; }
      const k = 'gb_' + Date.now();
      GB[k] = { box: BOX.map(({ pop, ...x }) => x), count: COUNT, to: (document.getElementById('gbTo') || {}).value || '', msg: (document.getElementById('gbMsg') || {}).value || '' };
      cart[k] = 1; save(); badge(); BOX = []; COUNT = 1;
      if (typeof toast === 'function') toast('বক্স কার্টে যোগ হয়েছে ✓');
      go('cart');
    }
  }, true);
  document.addEventListener('input', (e) => {
    if (e.target.id !== 'bxCntIn') return;
    const n = parseInt(num(e.target.value), 10); if (n >= 1) { COUNT = Math.min(1000, n); redraw(); }
  });
  // ডেমোতে পাতা আগেই আঁকা হয়ে যায় — তাই একবার আবার আঁকি
  if (document.getElementById('view') && P.length) render();
})();
