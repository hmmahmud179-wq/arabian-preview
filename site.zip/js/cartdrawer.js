/* Cart drawer: tapping the cart (floating button, bottom menu, any "#cart" link) opens a small
   panel from the right instead of a separate page. Visiting /#cart directly still shows the full page. */
(function () {
  'use strict';
  if (typeof cartView !== 'function') return;

  const css = `
.cdraw{position:fixed;inset:0;z-index:60}
.cdraw .cd-bg{position:absolute;inset:0;background:rgba(0,0,0,.45);opacity:0;transition:opacity .22s}
.cdraw .cd-panel{position:absolute;top:0;right:0;bottom:0;width:min(400px,92vw);background:var(--bg);color:var(--fg);
  display:flex;flex-direction:column;box-shadow:-10px 0 30px rgba(0,0,0,.25);transform:translateX(100%);transition:transform .25s ease-out;
  padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px);padding-right:env(safe-area-inset-right,0px)}
.cdraw.on .cd-bg{opacity:1}.cdraw.on .cd-panel{transform:none}
.cdraw .cd-head{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:12px 14px;border-bottom:1px solid var(--line)}
.cdraw .cd-head b{font-size:17px}
.cdraw .cd-x{border:0;background:transparent;color:var(--fg);font-size:26px;line-height:1;width:40px;height:40px;cursor:pointer;border-radius:10px}
.cdraw .cd-x:hover{background:var(--surface)}
.cdraw .cd-body{flex:1;overflow:auto;overscroll-behavior:contain}
.cdraw .cd-body .sec{padding:12px 14px 18px;margin:0;max-width:none}
.cdraw .cd-body .sec>h2{display:none}
.cdraw .cd-body .plist{grid-template-columns:repeat(2,minmax(0,1fr))}
.cdraw .cd-foot{border-top:1px solid var(--line);padding:10px 14px 12px;display:flex;flex-direction:column;gap:8px;background:var(--bg)}
.cdraw .cd-foot:empty{display:none}
.cdraw .cd-foot .sum{margin:0;padding:0;border:0;background:transparent;gap:4px;font-size:14px}
.cdraw .cd-foot .btn{width:100%}
html.cd-open,html.cd-open body{overflow:hidden}
@media (prefers-reduced-motion:reduce){.cdraw .cd-bg,.cdraw .cd-panel{transition:none}}`;
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  let el = null; let lastFocus = null;
  const isOpen = () => !!(el && !el.hidden);

  function fill() {
    if (!el) return;
    const n = typeof count === 'function' ? count() : 0;
    el.querySelector('.cd-head b').textContent = n ? `আপনার কার্ট (${bn(n)})` : 'আপনার কার্ট';
    const body = el.querySelector('.cd-body'); const foot = el.querySelector('.cd-foot');
    const top = body.scrollTop;
    body.innerHTML = cartView(); foot.innerHTML = '';
    // Total and the order button stay visible at the bottom of the panel.
    const sec = body.querySelector('.sec');
    const sum = sec && sec.querySelector(':scope > .sum');
    const go = sec && sec.querySelector(':scope > a.btn[href="#checkout"]');
    if (sum) foot.appendChild(sum);
    if (go) foot.appendChild(go);
    body.scrollTop = top;
  }

  function open() {
    if (!el) {
      el = document.createElement('div');
      el.className = 'cdraw'; el.hidden = true;
      el.innerHTML = '<div class="cd-bg" data-cdclose></div><aside class="cd-panel" role="dialog" aria-modal="true" aria-label="আপনার কার্ট">'
        + '<div class="cd-head"><b>আপনার কার্ট</b><button type="button" class="cd-x" data-cdclose aria-label="বন্ধ করুন">×</button></div>'
        + '<div class="cd-body"></div><div class="cd-foot"></div></aside>';
      document.body.appendChild(el);
      el.addEventListener('click', (e) => { if (e.target.closest('[data-cdclose]')) { e.preventDefault(); close(); } });
    }
    lastFocus = document.activeElement;
    fill();
    el.hidden = false;
    document.documentElement.classList.add('cd-open');
    requestAnimationFrame(() => el.classList.add('on'));
    el.querySelector('.cd-x').focus({ preventScroll: true });
  }

  function close(instant) {
    if (!isOpen()) return;
    el.classList.remove('on');
    document.documentElement.classList.remove('cd-open');
    const done = () => { el.hidden = true; };
    if (instant) done(); else setTimeout(done, 230);
    if (lastFocus && lastFocus.focus && !instant) lastFocus.focus({ preventScroll: true });
  }

  // Any link to #cart opens the drawer (unless the full cart page is already showing).
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href="#cart"]');
    if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey) return;
    if (location.hash === '#cart') return;
    e.preventDefault();
    if (typeof closeMenus === 'function') closeMenus();
    document.querySelectorAll('.mdrawer').forEach((x) => x.remove());
    open();
  }, true);

  // Quantity / add buttons inside the drawer change the cart; redraw it afterwards.
  document.addEventListener('click', () => { if (isOpen()) setTimeout(fill, 0); });
  const _render = render;
  render = function () { const out = _render.apply(this, arguments); if (isOpen()) fill(); return out; };

  // Going to another page (checkout, a product) closes it.
  window.addEventListener('hashchange', () => close(true));
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });

  window.openCartDrawer = open;
})();
